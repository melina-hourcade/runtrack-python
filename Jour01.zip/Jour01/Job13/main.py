num1 = input("Enter a number 1 : ")
num2 = input("Enter a number 2 : ")
num3 = input("Enter a number 3 : ")
num4 = input("Enter a number 4 : ")
num5 = input("Enter a number 5 : ")

list = [num1, num2, num3, num4, num5]
print(list)
listCroissant = sorted(list)
print(listCroissant)

